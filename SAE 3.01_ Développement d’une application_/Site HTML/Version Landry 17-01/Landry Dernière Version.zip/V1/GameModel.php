<?php

class GameModel {
    private $connection;

    public function __construct() {
        require 'nbpn.php';
        $this->connection = $connection;
        $this->connection->query("SET NAMES 'utf8'");
        $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //error mode 
    }

    // Méthode pour récupérer tous les jeux
    public function getAllGames() {
        $sql = "
        SELECT 
            jeux.id_jeu,
            jeux.titre,
            jeux.date_parution_debut,
            jeux.date_parution_fin,
            jeux.information_date,
            jeux.version,
            jeux.nombre_de_joueurs,
            jeux.age_indique,
            jeux.mots_cles,
            COALESCE(mecanisme.nom, 'Type inconnu') AS mecanisme,
            -- Récupérer les noms des auteurs associés au jeu
            string_agg(DISTINCT COALESCE (auteur.nom, 'Auteur inconnu'),', ') AS auteurs,
            -- Récupérer les noms des éditeurs associés au jeu
            string_agg(DISTINCT COALESCE (editeur.nom, 'Editeur inconnu'),', ') AS editeurs
        FROM jeux
        -- Association avec les mécanismes
        LEFT JOIN mecanisme ON mecanisme.mecanisme_id = jeux.mecanisme_id
        -- Associations avec les auteurs via jeu_auteur
        LEFT JOIN jeuauteur ON jeuauteur.jeu_id = jeux.id_jeu
        LEFT JOIN auteur ON auteur.auteur_id = jeuauteur.auteur_id
        -- Associations avec les éditeurs via jeu_editeur
        LEFT JOIN jeuediteur ON jeuediteur.jeu_id = jeux.id_jeu
        LEFT JOIN editeur ON editeur.editeur_id = jeuediteur.editeur_id
        GROUP BY 
            jeux.id_jeu, jeux.titre, jeux.date_parution_debut, jeux.date_parution_fin,
            jeux.information_date, jeux.version, jeux.nombre_de_joueurs, jeux.age_indique, 
            jeux.mots_cles, mecanisme.nom
    ";
    //var_dump($sql);
    return $this->connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Méthode pour rechercher un jeu par nom
public function getGameByName($name) {
    $sql = "SELECT 
                jeux.id_jeu, 
                jeux.titre, 
                jeux.date_parution_debut, 
                jeux.date_parution_fin, 
                jeux.information_date, 
                jeux.version, 
                jeux.nombre_de_joueurs, 
                jeux.age_indique, 
                jeux.mots_cles, 
                COALESCE(mecanisme.nom, 'Type inconnu') AS mecanisme,
                string_agg(DISTINCT auteur.nom, ', ') AS auteurs,
                string_agg(DISTINCT editeur.nom, ', ') AS editeurs
            FROM jeux
            LEFT JOIN mecanisme ON mecanisme.mecanisme_id = jeux.mecanisme_id
            LEFT JOIN jeuauteur ON jeuauteur.jeu_id = jeux.id_jeu
            LEFT JOIN auteur ON auteur.auteur_id = jeuauteur.auteur_id
            LEFT JOIN jeuediteur ON jeuediteur.jeu_id = jeux.id_jeu
            LEFT JOIN editeur ON editeur.editeur_id = jeuediteur.editeur_id
            WHERE jeux.titre ILIKE :name
            GROUP BY jeux.id_jeu, jeux.titre, jeux.date_parution_debut, jeux.date_parution_fin, 
                     jeux.information_date, jeux.version, jeux.nombre_de_joueurs, 
                     jeux.age_indique, jeux.mots_cles, mecanisme.nom";

    $stmt = $this->connection->prepare($sql);
    $searchTerm = $name . '%'; // Rechercher les jeux qui commencent par $name
    $stmt->bindParam(':name', $searchTerm);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC); // Récupérer tous les jeux correspondant
}
public function CreerUtilisateur($nom, $prenom,$numero_etu,$mot_de_passe,$mot_de_passe_final,$mot_de_passe_hache, $regex){
    
        
        // Préparer et exécuter la requête d'insertion
        if(preg_match($regex,$mot_de_passe_final) && $mot_de_passe_final == $mot_de_passe){
        $stmt = $this->connection->prepare('INSERT INTO utilisateurs (numero_etu ,nom, prenom, mot_de_passe) VALUES (:numero_etu, :nom ,:prenom, :mot_de_passe)');
        $stmt->execute([
            ':numero_etu'=>$numero_etu,
            ':nom' => $nom,
            ':prenom'=> $prenom,
            ':mot_de_passe' => $mot_de_passe_hache
        ]);

        echo "Inscription réussie ! Vous pouvez maintenant vous connecter.";
    }
    else{
        echo "insérer un mot de passe d'une longueur de 8 avec une majuscule au moins un chiffre et un caractère spécial";
    }
    }
}   


?> 