<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Jeux</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        
        .container {
            padding: 20px;
        }
        .game-card {
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #f9f9f9;
        }
        .game-card h3 {
            margin-top: 0;
        }
        .game-card button {
            background-color: #002147;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .game-card button:hover {
            background-color: #003366;
        }
        .footer {
            background-color: #d3bda8;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
            .search-bar {
    display: flex;
    align-items: center;
}

header {
    display: flex;

    align-items: center;
    justify-content: space-between;
    background-color: #A8917E;
    padding: 10px 20px;
}

header img {
    max-height: 40px;
}

nav {
    display: flex;
    gap: 20px;
}

nav a {
    margin: 0 10px;
    color: #333;
    text-decoration: none;
    font-weight: bold;
}

nav a:hover {
    text-decoration: underline;
}

.search-bar {
    display: flex;
    align-items: center;
    border-radius: 10px;
}

.search-bar input {
    padding: 5px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.search-bar button {
    margin-left: 5px;
    padding: 5px 10px;
    background-color: #333;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
    </style>

</head>
<body>
    <header>
        <a href="accueil.html"><img src="img/LogoUSPN.png" alt="Sorbonne Paris Nord"></a>
        <nav>
            <a href="#">Documentation</a>
            <a href="collection.php">Collection</a>
            <a href="reservation.html">Réservation</a>
            <a href="https://cas.univ-paris13.fr/cas/login?service=https%3A%2F%2Fent.univ-paris13.fr">ENT</a>
        </nav>
        <div class="search-bar">
			<form action="index.php" method="get">
				<input type="hidden" name="action" value="searchGame">
				<input type="text" name="query" placeholder="Rechercher un jeu..." required>
				<button type="submit">🔍</button>
			</form>
		</div> 
        <a href="connexion.html"><div class="user-icon">👤</div></a>
    </header>

    <h1>Bienvenue à la collection de jeux</h1>
    <div class="container">
        <h1>Liste des Jeux</h1>

        <?php if (!empty($games)): ?>
            <?php foreach ($games as $game): ?>
                <div class="game-card">
                    <h3><?= htmlspecialchars($game['titre']) ?></h3>
                    <p><strong>Auteur :</strong> <?= htmlspecialchars($game['auteurs']) ?></p>
                    <p><strong>Éditeur :</strong> <?= htmlspecialchars($game['editeurs']) ?></p>
                    <p><strong>Année de publication :</strong> <?= htmlspecialchars($game['date_parution_debut']) ?></p>
                    <p><strong>Nombre de joueurs :</strong> <?= htmlspecialchars($game['nombre_de_joueurs']) ?></p>
                    <p><strong>Type de jeu :</strong> <?= htmlspecialchars($game['mecanisme']) ?></p>
                    <button>Réserver</button>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucun jeu trouvé dans la base de données.</p>
        <?php endif; ?>
    </div>

    <footer class="footer">
        Mentions légales | Politique de cookies | Protection de données
    </footer>
</body>
</html>