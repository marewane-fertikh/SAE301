<?php
// Inclusion du modèle
require_once 'GameModel.php';

// Initialisation du modèle
$gameModel = new GameModel();

// Vérification si une recherche a été soumise
$query = $_GET['query'] ?? null;
if ($query) {
    // Recherche des jeux contenant le terme saisi
    $games = $gameModel->getGameByName($query);
} else {
    // Si aucune recherche, récupérer tous les jeux
    $games = $gameModel->getAllGames();
}

// Inclusion de la vue
include 'Home_View.php';