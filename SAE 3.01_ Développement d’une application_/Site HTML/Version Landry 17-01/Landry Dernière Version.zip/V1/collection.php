<?php
// index.php - Affichage des produits

// Inclure la connexion à la base de données
include('db.php');

// Récupérer les produits depuis la base de données
$query = 'SELECT * FROM products';
$stmt = $pdo->query($query);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Politique de Cookies - Sorbonne Paris Nord</title>
    <link rel="stylesheet" href="politique_styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
</head>
<body>
    <header>
        <a href="accueil.html"><img src="img/LogoUSPN.png" alt="Sorbonne Paris Nord"></a>
        <nav>
            <a href="#">Documentation</a>
            <a href="#">Collection</a>
            <a href="reservation.html">Réservation</a>
            <a href="https://etd.univ-spn.fr">ENT</a>
        </nav>
        <div class="search-bar">
			<form action="index.php" method="get">
				<input type="hidden" name="action" value="searchGame">
				<input type="text" name="query" placeholder="Rechercher un jeu..." required>
				<button type="submit">🔍</button>
			</form>
		</div> 
        <a href="connexion.html"><div class="user-icon">👤</div></a>
    </header>

    <main class="main">


      <div class="container mt-4">
          <div class="row">
              <?php foreach ($products as $product): ?>
                  <div class="col-md-4">
                      <div class="card">
                          <img src="<?= $product['image_url']; ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']); ?>">
                          <div class="card-body">
                              <h5 class="card-title"><?= htmlspecialchars($product['name']); ?></h5>
                              <p class="card-text"><?= htmlspecialchars($product['description']); ?></p>
                              <p class="card-text"><strong><?= number_format($product['price'], 2, ',', ' '); ?> €</strong></p>
                              <a href="#" class="btn btn-primary">Ajouter au panier</a>
                          </div>
                      </div>
                  </div>
              <?php endforeach; ?>
          </div>
      </div>

      <!-- Ajout de Bootstrap JS -->
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>


    </main>

    <footer class="footer">
      <p>
          <a>© 2025 Sorbonne Paris Nord | Tous droits réservés.</a>
          <a href="mentions.html">Mentions légales</a> |
          <a href="politique.html">Politique de cookies</a> |
          <a href="protection.html">Protection de données</a>
      </p>
    </footer>
</body>
</html>
